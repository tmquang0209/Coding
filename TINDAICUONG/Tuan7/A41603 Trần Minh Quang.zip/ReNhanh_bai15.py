#In ra ngày kế tiếp của ngày được nhập vào

#Hàm lấy ngày của tháng
def dayOfMonth(year, month):
    if month in [1, 3, 5, 7, 8, 10, 12]: #Nếu là tháng 1,3,5,7,8,10,12
        return 31
    elif month in [4, 6, 9, 11]: #Nếu là tháng 4,6,9,11
        return 30
    elif month == 2: #Nếu là tháng 2
        if year % 4 == 0: #Năm nhuận
            return 29
        else:
            return 28
    else:
        return 0

#Nhập vào ngày, tháng, năm
input = input("Nhập ngày/tháng/năm: ")

#Tách chuỗi theo dấu /
input = input.split("/")

#Lấy ngày, tháng, năm
day = int(input[0])
month = int(input[1])
year = int(input[2])

#Kiểm tra ngày, tháng, năm
if day > dayOfMonth(year, month):
    print("Ngày không hợp lệ")
elif month > 12:
    print("Tháng không hợp lệ")
else:
    if month < 12 and day < dayOfMonth(year, month): #Nếu tháng nhập vào nhỏ hơn 12 và ngày nhập vào nhỏ hơn ngày của tháng nhập vào
        day += 1
    elif month < 12 and day == dayOfMonth(year, month): #Nếu tháng nhập vào nhỏ hơn 12 và ngày nhập vào bằng ngày của tháng nhập vào
        day = 1
        month += 1
    elif month == 12 and day == dayOfMonth(year, month): #Nếu tháng nhập vào bằng 12 và ngày nhập vào bằng ngày của tháng nhập vào
        day = 1
        month = 1
        year += 1
    elif month == 12 and day < dayOfMonth(year, month): #Nếu tháng nhập vào bằng 12 và ngày nhập vào nhỏ hơn ngày của tháng nhập vào
        day += 1

print("Ngày tiếp theo: %d/%d/%d" % (day, month, year))
