#Nhập vào 3 điểm toán, lý, hóa.
#Tính tổng điểm 3 môn
#Công thức: tongDiem = toan*2 + ly + hoa


diemToan,diemLy,diemHoa = float(input("Nhap diem toan: ")),float(input("Nhap diem ly: ")),float(input("Nhap diem hoa: "))
tongDiem = (diemToan*2 + diemLy + diemHoa)
print("Tong diem la: ",tongDiem)