n = int(input("Nhap n: "))

max = n
while n > 0:
    n = int(input("Nhap n: "))
    if n > max and n > 0:
        max = n
    

print("Max: ", max)