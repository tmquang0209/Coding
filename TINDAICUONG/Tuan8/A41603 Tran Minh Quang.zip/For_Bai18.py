#In ra màn hình các số từ 1 đến 10 trên cùng 1 dòng và các số cách nhau 1 dấu cách (space)

for i in range(1,11):
    print(i,end=' ')