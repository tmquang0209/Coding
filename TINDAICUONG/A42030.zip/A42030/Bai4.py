#Chuyển thập phân thành nhị phân

n = int(input("Nhập n:"))
s = ""
while n > 0:
    s = str(n % 2) + s
    n = n // 2
print("Số nhị phân của số thập phân là:", s)

