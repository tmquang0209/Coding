#In ra màn hình 5 dòng chữ Hello World!
i = 0
while i <= 5:
    print("Hello World!")
    i += 1
