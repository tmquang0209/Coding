#In ra màn hình các số từ 1 đến 10 trên cùng 1 dòng và các số cách nhau 1 dấu cách (space)

i = 1
while i <= 10:
    print(i, end = ' ')
    i += 1