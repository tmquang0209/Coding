#In ra màn hình 5 dòng chữ Hello World!
for i in range(5):
    print("Hello World!")