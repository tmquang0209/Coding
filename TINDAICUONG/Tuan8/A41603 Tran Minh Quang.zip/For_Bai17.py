#In ra màn hình n chữ “Hello”, với n nhập vào từ bàn phím

n = int(input("Nhap n: "))
for i in range(n):
    print("Hello")